-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2014 at 04:48 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `store`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `summary` text COLLATE utf8_unicode_ci NOT NULL,
  `cover` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `price`, `category_id`, `summary`, `cover`, `created_at`, `updated_at`) VALUES
(1, 'The Design of the UNIX Operating System', 'Maurice J. Bach', 1, 1, 'This book describes the internal algorithms and the structures that form the basis of the UNIXÂ® operating system and their relationship to the programmer interface. The system description is based on UNIX System V Release 2 supported by AT&T, with some features from Release 3. ', 'Koala.jpg', '2013-07-12 09:10:11', '2014-05-24 03:45:05'),
(2, 'Programming in Scala', 'Martin Odersky, Lex Spoon, and Bill Venners', 29, 4, 'This book is a tutorial for the Scala programming language, written by people directly involved in the development of Scala. Our goal is that by reading this book, you can learn everything you need to be a productive Scala programmer. All examples in this book compile with Scala version 2.7.2.', 'scala.jpg', '2013-07-12 09:11:39', '2013-07-12 09:11:39'),
(3, 'Beginning Perl', 'Curtis â€œOvidâ€ Poe', 39, 4, 'Perl is the ever-popular, flexible, open source programming language that has been called the programmersâ€™ Swiss army knife. This book introduces Perl to both new programmers and experienced ones who are looking to learn a new language. In the tradition of the popular Wrox Beginning guides, it presents step-by-step guidance in getting started, a host of try-it-out exercises, real-world examples, and everything necessary for a Perl novice to start programming with confidence.', 'perl.jpg', '2013-07-12 09:13:28', '2013-07-12 09:13:28'),
(4, 'Ubuntu Pocket Guide and Reference', 'Keir Thomas', 9, 1, 'A very well written introductory book with no fluf for the Ubuntu operating system. The book is rather dated though (Hasnt been updated since 2009) and new users may be confused with the changes such as the Unity interface that have gone into Ubuntu over the years. ', 'ubuntu.jpg', '2013-07-12 09:15:06', '2013-07-12 09:15:06'),
(5, 'Introduction to Data Science', 'Jeffrey Stanton ', 59, 1, 'This book provides non-technical readers with a gentle introduction to essential concepts and activities of data science. For more technical readers, the book provides explanations and code for a range of interesting applications using the open source R language for statistical computing and graphics', 'data.jpg', '2013-07-12 09:15:42', '2013-07-12 09:15:42'),
(6, 'UX Design for Startups', 'Marcin Treder ', 39, 1, 'A must read for any startup or grown-up company that wishes to keep its startup spirit and conquer the world with stunning UX Design.', 'ux.jpg', '2013-07-12 09:16:16', '2013-07-12 09:16:16');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remark` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `remark`, `created_at`, `updated_at`) VALUES
(1, 'Technology', '', '2013-06-22 01:49:41', '2013-06-22 01:49:41'),
(2, 'History', '', '2013-06-22 01:49:45', '2013-06-22 01:49:45'),
(3, 'Sci-Fi', '', '2013-06-22 01:49:54', '2013-06-22 01:49:54'),
(4, 'Language', '', '2013-06-22 01:50:05', '2013-06-22 01:50:05');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_05_22_091554_books', 1),
('2014_05_22_091630_categories', 1),
('2014_05_22_091647_orders', 1),
('2014_05_22_091703_order_book', 1),
('2014_05_22_091719_users', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `email`, `phone`, `address`, `status`, `created_at`, `updated_at`) VALUES
(1, 'userone', 'userone@test.com', '092343224', 'Sanchaung', 0, '2013-06-22 01:49:41', '2014-07-17 02:16:00'),
(2, 'userone', 'userone@test.com', '093242342', 'Sanchaung', 0, '2013-06-22 01:49:41', '2014-07-20 02:29:52'),
(12, 'user two', 'usertwo@test.com', '2342342342', 'Yangon', 1, '2014-07-20 04:21:51', '2014-07-27 03:19:27'),
(14, 'User Two', 'usertwo@test.com', '3042042099', 'Sanchaung', 1, '2014-07-27 02:58:05', '2014-07-27 02:58:30'),
(15, 'User Two', 'usertwo@test.com', '2340232322', 'Yangon', 0, '2014-07-27 03:18:33', '2014-07-27 03:18:33'),
(16, 'User One', 'userone@test.com', '3492394203', 'Yangon', 0, '2014-08-01 08:08:58', '2014-08-01 08:08:58');

-- --------------------------------------------------------

--
-- Table structure for table `order_book`
--

CREATE TABLE IF NOT EXISTS `order_book` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `order_book`
--

INSERT INTO `order_book` (`id`, `book_id`, `order_id`, `qty`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 3, '2013-06-22 01:49:41', '2013-06-22 01:49:41'),
(2, 2, 1, 3, '2013-06-22 01:49:41', '2013-06-22 01:49:41'),
(3, 3, 2, 2, '2013-06-22 01:49:41', '2013-06-22 01:49:41'),
(7, 2, 12, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 1, 12, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 3, 12, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 1, 14, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 2, 14, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 3, 14, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 1, 15, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 2, 15, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 1, 16, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 2, 16, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `name`, `password`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'userone@test.com', 'User One', '$2y$10$IRFNujb.HGcuzLf3gr3ot.DYFAmQFD3BaVOXH1qDG.zJ1aQsz64j6', '1', 'hJWjolz7vukRtqxoLW93fdi6mR0jBJ2zf2DORhY2EJMpn9pvebafYa3xpyzR', '2014-05-22 02:55:26', '2014-08-01 08:17:28');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
