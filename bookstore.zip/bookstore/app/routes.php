<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', 'BookController@getIndexList');

Route::get('test', function()
{
	$user = new User;
	
	$user->email = "usertwo@test.com";
	$user->name = "User two";
	$user->password = "usertwo";
	$user->status = 1;
	
	$user->save();
	
	return "Test user has been save to database";
});

Route::get('login','AuthController@getLogin');
Route::post('login','AuthController@postLogin');
Route::get('logout','AuthController@getLogout');

Route::controller('bookList', 'BookController');
Route::controller('categoryList', 'CategoryController');
Route::controller('orders', 'OrderController');
