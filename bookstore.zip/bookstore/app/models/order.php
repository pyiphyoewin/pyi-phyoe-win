<?php

class Order extends Eloquent
{
	protected $table = 'orders';
}