<?php

class Book extends Eloquent
{
	protected $table = 'books';
}