<?php

class OrderController extends BaseController {

	/**
	 * Setting the before filter for authentication
	 *
	 */
	//public function __construct()
	//{
	//	$this->beforeFilter('auth',array('except' => 'getLogin'));
	//}
	
	//public function books()
	//{
	//	return $this->belongsToMany('Book', 'order_book', 'order_id', 'book_id');
		//return $this->has_many_and_belongs_to('Book', 'order_book', 'order_id', 'book_id');
	//}
	/**
	 * Getting all users to display
	 *
	 */
	public function getIndex()
	{
	$this->beforeFilter('auth',array('except' => 'getLogin'));
	$items=DB::table('order_book')
					->join('orders','order_id','=','orders.id')
					->join('books','book_id','=','books.id')
					->select('order_book.*','books.title')->get();
	
		$orders = Order::paginate(3);
		//$books = Order::find(1)->books;
		//return $books;
		return View::make('admin.orders',array('orders'=>$orders,'items'=>$items));
	}
	
	public function getUpdate($order_id,$status)
	{
	$this->beforeFilter('auth',array('except' => 'getLogin'));
		$order = Order::find($order_id);
		if(is_null($order))
		{
			return Redirect::to('orders');
		}
		
		$order->status = $status;
		
		$order->save();
		
		return Redirect::to('orders');
	}
	
	public function postCreate(){
		$rules = array(
			'email' => 'email',
			'phone' => 'numeric',
		);
		
		$validation = Validator::make(Input::all(), $rules);
		
		if($validation->fails()){
			return Redirect::back()->withErrors($validation);
		}
		
		$order = new Order;
		
		$order->name = Input::get('name');
		$order->email = Input::get('email');
		$order->phone = Input::get('phone');
		$order->address = Input::get('address');
		
		$order->save();
		$insertedId = $order->id;
		
		if(Session::has('cart')){
			$carts=Session::get('cart');
			foreach($carts as $cart){
				DB::table('order_book')->insert(
					array('book_id' => $cart[0], 'order_id' => $insertedId, 'qty' => $cart[1]));
			}
		}

		Session::flush();
		
		return View::make('submit-order');
	}
	
}