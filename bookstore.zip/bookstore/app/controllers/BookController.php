<?php

class BookController extends BaseController {
	public $count=1;
	/**
	 * Setting the before filter for authentication
	 *
	 */
	//public function __construct()
	//{
	//	$this->beforeFilter('auth',array('except' => 'getLogin'));
	//}
	
	//public function orders()
	//{
		//return $this->belongsToMany('Order', 'order_book', 'order_id', 'book_id');
		//return $this->has_many_and_belongs_to('Order', 'order_book', 'order_id', 'book_id');
	//}
	
	/**
	 * Getting all users to display
	 *
	 */
	public function getIndex()
	{
		$books = Book::paginate(5);
		
		return View::make('admin.book-list')->with('books', $books);
	}
	
	public function getCreate()
	{
		$categories = Category::all();
		
		return View::make('admin.book-new')->with('categories', $categories);
	}
	
	public function postCreate()
	{
		$rules = array(
			'price' => 'numeric',
		);
		
		$validation = Validator::make(Input::all(), $rules);
		
		if($validation->fails()){
			return Redirect::back()->withErrors($validation);
		}
		$book = new Book;
		
		$book->title = Input::get('title');
		$book->author = Input::get('author');
		$book->summary = Input::get('summary');
		$book->price = Input::get('price');
		$book->category_id = Input::get('category_id');
		$book->cover = Input::file('cover')->getClientOriginalName();
		Input::file('cover')->move('packages/assets/img/covers', $book->cover);
		
		
		$book->save();
		
		return Redirect::to('bookList');
	}
	
	public function getUpdate($book_id)
	{
		$book = Book::find($book_id);
		if(is_null($book))
		{
			return Redirect::to ('bookList');
		}
		$categories = Category::all();
		return View::make('admin.book-edit', array('book' => $book, 'categories' => $categories));
	}
	
	public function postUpdate($book_id)
	{
		$book = Book::find($book_id);
		if(is_null($book))
		{
			return Redirect::to ('bookList');
		}
		
		$book->id = Input::get('id');
		$book->title = Input::get('title');
		$book->author = Input::get('author');
		$book->summary = Input::get('summary');
		$book->price = Input::get('price');
		$book->price = Input::get('category_id');
		$cover = Input::file('cover')->getClientOriginalName();
		if($cover)
		{
			$book->cover = Input::file('cover')->getClientOriginalName();
			Input::file('cover')->move('packages/assets/img/covers', $book->cover);
		}
		$book->save();
		return Redirect::to('bookList');
	}
	
	public function getDelete($book_id)
	{
		$book = Book::find($book_id);
		
		if(is_null($book))
		{
			return Redirect::to ('bookList');
		}
		
		$book->delete();
		
		return Redirect::to('bookList');
	}
	
	public function getIndexList()
	{
		$books = Book::all();
		$categories = Category::all();
		$carts=$this->checkSession();
		return View::make('index',array('books'=>$books,'categories'=>$categories,'carts'=>$carts));
	}
	public function checkSession(){
		$carts=array();
		if(Session::has('cart')){
			$carts=Session::get('cart');
		}
		return $carts;
	}
	
	public function getCategory($cat_id)
	{
		$books = Book::where('category_id','=',$cat_id)->get();
		$categories = Category::all();
		$carts=$this->checkSession();
	
		return View::make('index',array('books'=>$books,'categories'=>$categories, 'carts'=>$carts));
	}
	
	public function getCart($book_id)
	{
		$id = $book_id;
		$point=0;
		$data=array();
		if(Session::has('cart')){
			$data=Session::get('cart');
			for($i=0;$i<count($data);$i++){
				if($data[$i][0]==$id){
					$data[$i][1]=$data[$i][1]+1;
					$point=1;
				}
			}
			if($point==0){
				$newData=array($id,1);
				array_push($data,$newData);
			}
		} else{
			$newData=array($id,1);
			array_push($data,$newData);
		}
		Session::put('cart',$data);
		return Redirect::to('/');
	}
	public function getShop(){
		if(Session::has('cart'))
		{
			$carts=Session::get('cart');
			$books = Book::all();
			return View::make('view-cart', array('books'=>$books,'carts'=>$carts));
		}
		return Redirect::to('/');
	}
	
	public function getClear(){
		if(Session::has('cart')){
			Session::flush();
		}
		return Redirect::to('/');
	}
	
	public function getDetail($id){
		$book = Book::find($id);
		return View::make('book-detail')->with('book', $book);
	}
	
	public function appendURL($data, $prefix)
	  {
		foreach ($data as $key => & $item) {
		  $item['url'] = url($prefix.'/'.$item['id']);
		}
		return $data;  
	  }
  
	public function getSearch(){
		$query = e(Input::get('q',''));
	 
		if(!$query && $query == '') return Response::json(array(), 400);
	 
		$books = Book::where('title','like','%'.$query.'%')
		  ->orderBy('title','asc')
		  ->take(5)
		  ->get(array('id','title'))->toArray();
	 
		
		// Data normalization
		$books   = $this->appendURL($books, 'bookList/book');
	 
	 
		return Response::json(array(
		  'data'=>$books
		));
	}
	
	public function getBook($id){
		$books = Book::find($id);
		$categories = Category::all();
		$carts=$this->checkSession();
		return View::make('index',array('books'=>$books,'categories'=>$categories,'carts'=>$carts));
	}
}