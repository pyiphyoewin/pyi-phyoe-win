<?php

class CategoryController extends BaseController {

	/**
	 * Setting the before filter for authentication
	 *
	 */
	public function __construct()
	{
		$this->beforeFilter('auth',array('except' => 'getLogin'));
	}
	
	/**
	 * Getting all users to display
	 *
	 */
	public function getIndex()
	{
		$categories = Category::all();
		
		return View::make('admin.cat-list')->with('categories', $categories);
	}
	
	public function getCreate()
	{
		return View::make('admin.cat-new');
	}
	
	public function postCreate()
	{
		$category = new Category;
		
		$category->name = Input::get('name');
		$category->remark = Input::get('remark');
		
		$category->save();
		
		return Redirect::to('categoryList');
	}
	
	public function getUpdate($category_id)
	{
		$category = Category::find($category_id);
		if(is_null($category))
		{
			return Redirect::to ('categoryList');
		}
		
		return View::make('admin.cat-edit')->with('category', $category);
	}
	
	public function postUpdate($category_id)
	{
		$category = Category::find($category_id);
		if(is_null($category))
		{
			return Redirect::to('categoryList');
		}
		$category->id = Input::get('id');
		$category->name = Input::get('name');
		$category->remark = Input::get('remark');
		
		$category->save();
		
		return Redirect::to('categoryList');
	}
	
	public function getDelete($category_id)
	{
		$category = Category::find($category_id);
		
		if(is_null($category))
		{
			return Redirect::to ('categoryList');
		}
		
		$category->delete();
		
		return Redirect::to('categoryList');
	}
}