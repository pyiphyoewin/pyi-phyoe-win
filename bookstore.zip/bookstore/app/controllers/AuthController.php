<?php

class AuthController extends BaseController {

	/**	 
	 * login function
	 *
	 * @return redirect to login page
	 */
	public function getLogin()
	{	
		$pass=0;
		return View::make('admin.index')->with('pass',$pass);
	}
	
	/**	 
	 * Validating login information
	 *
	 * @return login confirmation
	 */
	public function postLogin()
	{	
		$pass=1;
		$credentials = array(
		'email' => Input::get('email'),
		'password' => Input::get('password'));
		if(Auth::attempt($credentials))
		{
			if(Auth::user()->status == 1)
			{
				return Redirect::to('bookList');
			} else {
				return Redirect::to('/');
			}
		}
		else
		{
			return View::make('admin.index')->with('pass',$pass);
		}
	}
	
	/**	 
	 * Logout function
	 *
	 * @return Redirect to home page
	 */
	public function getLogout()
	{
		Auth::logout();
		
		return Redirect::to('/');
	}
}