<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>New Category</title>
		<link rel="stylesheet" href="{{asset('packages/assets/css/style.css')}}">
	</head>
	<body>
		<ul class="menu">
			<li><a href="../bookList">Manage Books</a></li>
			<li><a href="../categoryList">Manage Categories</a></li>
			<li><a href="../orders">Manage Orders</a></li>
			<li><a href="logout">Logout</a></li>
		</ul>
		<h1>New Category</h1>
		<form method="post">
			<label for="name">Category Name</label>
			<input type="text" name="name" id="name"/>
			
			<label for="remark">Remark</label>
			<textarea name="remark" id="remark"></textarea>
			
			<br /><br />
			<input type="submit" value="Add Category">
			<a href="../categoryList" class="back">Back</a>
		</form>
		
		<script src="../packages/assets/js/jquery.js"></script>
		<script src="../packages/assets/js/jquery.validate.min.js"></script>
		<script>
			$(function(){
				$("form").validate({
					rules: {
						"name": "required"
					},
					messages: {
						"name": "Please provide category name"
					}
				});
			});
		</script>
	</body>
</html>