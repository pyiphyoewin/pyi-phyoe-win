<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>Edit Book</title>
		<link rel="stylesheet" href="{{asset('packages/assets/css/style.css')}}">
	</head>
	<body>
@section('menu')
		<ul class="menu">
			<li><a href="../../bookList">Manage Books</a></li>
			<li><a href="../../categoryList">Manage Categories</a></li>
			<li><a href="../../orders">Manage Orders</a></li>
			<li><a href="logout">Logout</a></li>
		</ul>
@show
@section('content')
@show
	</body>
</html>