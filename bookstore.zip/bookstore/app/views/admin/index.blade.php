<!doctype html>
<html lang="en-US>
	<head>
		<meta charset="UTF-8">
		<title>Lgoin to Book Store Administration</title>
		<link rel="stylesheet" href="packages/assets/css/style.css"/>
	</head>
	<body>
		<h1>Lgoin to Book Store Administration</h1>
		<?php if($pass==1):?>
		<div class="error">Login failed! User name or password incorrect.</div>
		<?php endif;?>
		<form  method="post" class="login-form">
			<label for="email">Email</label>
			<input type="text" id="email" name="email"/>

			<label for="password">Password</label>
			<input type="password" id="password" name="password" />

			<br /><br />
			<input type="submit" value="Admin Login" />
		</form>
	</body>
</html>