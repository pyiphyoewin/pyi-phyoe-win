<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>New Book</title>
		<link rel="stylesheet" href="../packages/assets/css/style.css">
	</head>
	<body>
		<ul class="menu">
			<li><a href="../bookList">Manage Books</a></li>
			<li><a href="../categoryList">Manage Categories</a></li>
			<li><a href="../orders">Manage Orders</a></li>
			<li><a href="../logout">Logout</a></li>
		</ul>
		<h1>New Book</h1>
		<form  method="post" enctype="multipart/form-data">
			<label for="title">Book Title</label>
			<input type="text" name="title" id="title"/>
			
			<label for="author">Author</label>
			<input type="text" name="author" id="author"/>
			
			<label for="summary">Summary</label>
			<textarea name="summary" id="summary"></textarea>
			
			<label for="price">Price</label>
			<input type="text" name="price" id="price"/>
			<?php 
				if($errors->has('price')):
			?>
			<label class="error"><?php	echo $errors->first('price'); ?></label>
			<?php endif; ?>
			
			<label for="categories">Category</label>
			<select name="category_id" id="categories">
				<option value="0">-- Choose --</option>
				
				@foreach($categories as $category)
			
				<option value="{{ $category->id }}">
					{{ $category->name }}
				</option>
				
				@endforeach
			
			</select>
			<label for="cover">Cover</label>
			<input type="file" name="cover" id="cover" />
			<br /><br />
			<input type="submit" value="Add Book" />
			<a href="../bookList" class="back">Back</a>
		</form>
		<script src="../packages/assets/js/jquery.js"></script>
		<script src="../packages/assets/js/jquery.validate.min.js"></script>
		<script>
			$(function() {
				$("form").validate({
					rules: {
						"title": "required",
						"author": "required",
						"category_id": "required",
						"price": "required",
					},
					messages: {
						"title": "Please provide book title",
						"author": "Pleasse provide author name",
						"category_id": "Please choose a category",
						"price": "Please provide book price",
					}
				});
			});
		</script>
	</body>
</html>