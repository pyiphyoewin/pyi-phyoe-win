<!doctype html>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>Book List</title>
		<link rel="stylesheet" href="packages/assets/css/style.css">
		
	</head>
	<body>
		<ul class="menu">
			<li><a href="bookList">Manage Books</a></li>
			<li><a href="categoryList">Manage Categories</a></li>
			<li><a href="orders">Manage Orders</a></li>
			<li><a href="logout">Logout</a></li>
		</ul>
		<h1>Book List</h1>

		<ul class="list">
		
		@foreach($books as $book)
			<li>
				@if(!is_dir("packages/assets/img/covers/$book->cover") and file_exists("packages/assets/img/covers/$book->cover"))
					<img src="packages/assets/img/covers/{{ $book->cover }}" alt="" align="right" height="140" width="93"/>
				@else
					<img src="packages/assets/img/covers/no-cover.gif" alt="" align="right" height="140">
				@endif
				
				<b>{{ $book->title }}</b>
				<i>by {{ $book->author }}</i>
				<small>(in {{ $book->name }})</small>
				<span>${{ $book->price }}</span>
				<div>{{ $book->summary}}</div>
				
				[ <a href="bookList/delete/{{ $book->id }}" 
      			class="del" onClick="return confirm('Are you sure?')">del</a> ]
				[ <a href="bookList/update/{{ $book->id }}" class="edit">edit</a> ]
			</li>
		@endforeach
		</ul>
		<div class="pagination" style="float: right; margin-right:20px;">{{ $books->links(); }}</div>
		<a href="bookList/create" class="new">New Book</a>
		
		<br style="clear:both" />
		
	</body>
</html>