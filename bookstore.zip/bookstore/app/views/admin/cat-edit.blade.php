@extends('admin.menu')
		@section('menu')
			@parent
		@stop
		@section('content')
		<h1>Edit Category</h1>
		
		<form method="post">
			<input type="hidden" name="id" value="{{ $category->id }}"/>
			
			<label for="name">Category Name</label>
			<input type="text" name="name" id="name" value="{{ $category->name }}"/>
			
			<label for="remark">Remark</label>
			<textarea name="remark" id="remark">{{ $category->remark }}</textarea>
			
			<br /><br />
			<input type="submit" value="Update Category"/>
			<a href="../../categoryList">Back</a>
		</form>
		<script src="../packages/assets/js/jquery.js"></script>
		<script src="../packages/assets/js/jquery.validate.min.js"></script>
		<script>
			$(function() {
				$("form").validate({
					rules: {
						"name": "required"
					},
					messages: {
						"name": "Please provide category name"
					}
				});
			});
		</script>
@stop