<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>Category List</title>
		<link rel="stylesheet" href="packages/assets/css/style.css">
	</head>
	<body>
		<ul class="menu">
			<li><a href="bookList">Manage Books</a></li>
			<li><a href="categoryList">Manage Categories</a></li>
			<li><a href="orders">Manage Orders</a></li>
			<li><a href="logout">Logout</a></li>
		</ul>
<h1>Order List</h1>

<ul class="orders">
		@foreach($orders as $order)
			@if($order->status)
			<li class="delivered">
			@else
			<li>
			@endif
			<div class="order">
				<b>{{ $order->name }}</b>
				<i>{{ $order->email }}</i>
				<span>{{ $order->phone}}</span>
				<p>
					{{ $order->address }}
				</p>
				
				@if($order->status)
					* <a href="orders/update/{{ $order->id }}/0">
					Undo</a>
				@else
					* <a href="orders/update/{{ $order->id }}/1">
					Mark as Delivered</a>
				@endif
			</div>
			<div class="items">
				@foreach($items as $item)
				@if($order->id == $item->order_id)
				<b>
					<a href="../book-detail.php?id={{ $item->book_id }}">
						{{ $item->title }}
					</a>
					({{ $item->qty }})
				</b>
				@endif
				@endforeach
			</div>
			</li>
		@endforeach
	</ul>
	<div class="pagination" style="text-align: right; margin-right: 20px; margin-bottom: 20px">{{ $orders->links(); }}</div>
</body>
</html>