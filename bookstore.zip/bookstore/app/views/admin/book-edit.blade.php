@extends('admin.menu')
		@section('menu')
			@parent
		@stop
		@section('content')
		<h1>Edit Book</h1>
		<form method="post" enctype="multipart/form-data">
			<input type="hidden" name="id" value="{{ $book->id }}"/>
			
			<label for="title">Book Title</label>
			<input type="text" name="title" id="title" value="{{ $book->title }}" />
			
			<label for="author">Author</label>
			<input type="text" name="author" id="author" value="{{ $book->author }}" />
			
			<label for="summary">Summary</label>
			<textarea name="summary" id="summary">{{ $book->summary }}</textarea>
			
			<label for="price">Price</label>
			<input type="text" name="price" id="price" value="{{ $book->price }}" />
			
			<label for="categories">Category</label>
			<select name="category_id" id="categories">
				<option value="0">-- Choose --</option>
		
				@foreach($categories as $category)
				<option value="{{ $category->id }}"
						@if($category->id == $book->category_id) 
							selected
						@endif 
				>
					{{ $category->name }}
					
				</option>
				
				@endforeach
				
			</select>
			
			<br /><br />
			
			@if(!is_dir("packages/assets/img/covers/$book->cover") and file_exists("packages/assets/img/covers/$book->cover"))
			<img src="../../packages/assets/img/covers/{{$book->cover}}" alt="" height="150" width="93"/>
			@else
			<img src="../../packages/assets/img/covers/no-cover.gif" alt="" height="150px">
			@endif
			
			<label for="cover">Change Cover</label>
			<input type="file" name="cover" id="cover" />
			
			<br /><br />
			<input type="submit" value="Update Book" />
			<a href="../../bookList">Back</a>
		</form>
		
		<script src="../packages/assets/js/jquery.js"></script>
		<script src="../packages/assets/js/jquery.validate.min.js"></script>
		<script>
			$(function() {
				$("form").validate({
					rules: {
						"title": "required",
						"author": "required",
						"category_id": "required",
						"price": "required"
					},
					messages: {
						"title": "Please provide book title",
						"author": "Please provide author name",
						"category_id": "Please choose a category",
						"price": "Please provide book price"
					}
				});
			});
		</script>
	@stop