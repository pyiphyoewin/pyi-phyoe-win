<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>Category List</title>
		<link rel="stylesheet" href="packages/assets/css/style.css">
	</head>
	<body>
		<ul class="menu">
			<li><a href="bookList">Manage Books</a></li>
			<li><a href="categoryList">Manage Categories</a></li>
			<li><a href="orders">Manage Orders</a></li>
			<li><a href="logout">Logout</a></li>
		</ul>
		<h1>Category List</h1>
		
		<ul class="list">
			@foreach ($categories as $category)
			<li title="{{ $category->remark }}">
			[ <a href="categoryList/delete/{{ $category->id }}" 
			class="del" onClick="return confirm('Are you sure?')">del</a> ]
			[ <a href="categoryList/update/{{ $category->id }}" 
			class="edit">edit</a> ]
			{{ $category->name }}
			</li>
			@endforeach
		</ul>
		
		<a href="categoryList/create" class="new">New Category</a>
		
		<br style="clear:both" />
	</body>
</html>