<!doctype html>
<html>
	<head>
		<title>Book Store</title>
		<link rel="stylesheet" href="<?php echo asset('packages/assets/css/Hstyle.css')?>" />
		<link rel="stylesheet" href="<?php echo asset('vendor/selectize/css/selectize.bootstrap3.css')?>" />
		
		<script type="text/javascript" src="<?php echo asset('packages/assets/js/jquery.js')?>"></script>
		<script type="text/javascript" src="<?php echo asset("vendor/selectize/js/standalone/selectize.min.js") ?>"></script>
		
	</head>
	<body>
		<h1 id="title">Book Store</h1>
		<?php 	
			$total=0;
			foreach($carts as $cart):
				$total+=$cart[1];
			endforeach;
		?>
		<div class="info">
			<a href="<?php echo asset('bookList/shop') ?>">
				(<?php echo $total; ?>)books in your cart
			</a>
		</div>
		
		<div class="sidebar">
			<ul class="cats">
				<li>
					<b><a href="<?php echo asset('/')?>">All Categories</a></b>
				</li>
				<?php foreach($categories as $category): ?>
				<li>
					<a href="<?php echo asset("bookList/category/$category->id") ?>">
						<?php echo $category->name ?>
					</a>
				</li>
				<?php endforeach; ?>
				<select id="searchbox" name="q" placeholder="Search by title" class="form-control"></select>
			</ul>
		</div>
		
		<div class="main">
			<ul class="books">
				<?php 
				
				if(count($books)=='1'):
				
				?>
				<li>
					<?php if(!is_dir("packages/assets/img/covers/$books->cover") and file_exists("packages/assets/img/covers/$books->cover")): ?>
						<img src="<?php echo asset('packages/assets/img/covers/'.$books->cover) ?>" height="140" width="93" />
					<?php else: ?>
						<img src="<?php echo asset('packages/assets/img/covers/no-cover.gif') ?>" alt="" height="140">
					<?php endif; ?>
					
					<b>
						<a href="<?php echo asset('bookList/detail').'/'.$books->id ?>">
							<?php echo $books->title ?>
						</a>
					</b>
					
					<i>$<?php echo $books->price ?></i>
					
					<a href="<?php echo asset('bookList/cart/'.$books->id)?>" class="add-to-cart" >
						Add to Cart
					</a>
				</li>
				<?php else: ?>
				
				<?php foreach($books as $book): ?>
				<li>
					<?php if(!is_dir("packages/assets/img/covers/$book->cover") and file_exists("packages/assets/img/covers/$book->cover")): ?>
						<img src="<?php echo asset('packages/assets/img/covers/'.$book->cover) ?>" height="140" width="93" />
					<?php else: ?>
						<img src="<?php echo asset('packages/assets/img/covers/no-cover.gif') ?>" alt="" height="140">
					<?php endif; ?>
					
					<b>
						<a href="<?php echo asset('bookList/detail').'/'.$book->id ?>">
							<?php echo $book->title ?>
						</a>
					</b>
					
					<i>$<?php echo $book->price ?></i>
					
					<a href="<?php echo asset('bookList/cart/'.$book->id)?>" class="add-to-cart" >
						Add to Cart
					</a>
				</li>
				<?php endforeach; ?>
				<?php endif; ?>
			</ul>
		</div>
		
		<div class="footer">
			&copy; <?php echo date("Y") ?>. All right reserved.
		</div>
		<script type="text/javascript">
		$(document).ready(function(){
		var root = '{{url("/")}}';
		$('#searchbox').selectize({
        valueField: 'url',
        labelField: 'title',
        searchField: ['title'],
        maxOptions: 10,
        options: [],
        create: false,
        render: {
            option: function(item, escape) {
                return '<div>' +escape(item.title)+'</div>';
            }
        },
        load: function(query, callback) {
            if (!query.length) return callback();
            $.ajax({
                url: root+'/bookList/search',
                type: 'GET',
                dataType: 'json',
                data: {
                    q: query
                },
                error: function() {
                    callback();
                },
                success: function(res) {
                    callback(res.data);
                }
            });
        },
        onChange: function(){
            window.location = this.items[0];
        }
    });
  });
		</script>
	</body>
</html>