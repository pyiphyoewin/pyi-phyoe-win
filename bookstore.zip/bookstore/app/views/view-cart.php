<!doctype html>
<html>
	<head>
		<title>View Cart</title>
		<link rel="stylesheet" href="<?php echo asset('packages/assets/css/Hstyle.css')?>">
	</head>
	<body>
		<h1>View Cart</h1>
		<div class="sidebar">
			<ul class="cats">
				<li><a href="<?php echo asset('/') ?>">&laquo; Continue Shopping</a></li>
				<li><a href="<?php echo asset('bookList/clear') ?>" class="del">&times; Clear Cart</a></li>
			</ul>
		</div>
		
		<div class="main">
			<table>
				<tr>
					<th>Book Title</th>
					<th>Quantity</th>
					<th>Unit Price</th>
					<th>Price</th>
				</tr>
				
				<?php
				
					$total = 0;
					foreach($books as $book):
						foreach($carts as $cart):
							if($book->id == $cart[0]):
								$total += $book->price * $cart[1];
				?>
				
				<tr>
					<td><?php echo $book->title; ?></td>
					<td><?php echo $cart[1]; ?></td>
					<td><?php echo $book->price; ?></td>
					<td><?php echo $book->price * $cart[1]; ?></td>
				</tr>
				<?php 
							endif;
							
						endforeach;
					endforeach;
				?>
				<tr>
					<td colspan="3" align="right"><b>Total:</b></td>
					<td>$<?php echo $total; ?></td>
				</tr>
			</table>
			
			<div class="order-form">
				<h2>Order Now</h2>
				<form action="../orders/create" method="post">
					<label for="name">Your Name</label>
					<input type="text" name="name" id="name" required/>
					
					<label for="email">Email</label>
					<input type="text" name="email" id="email" required/>
					<?php 
						if($errors->has('email')):
					?>
						<label class="error"><?php	echo $errors->first('email'); ?></label>
					<?php endif; ?>
					<label for="phone">Phone</label>
					<input type="text" name="phone" id="phone" required/>
					<?php 
						if($errors->has('phone')):
					?>
						<label class="error"><?php	echo $errors->first('phone'); ?></label>
					<?php endif; ?>	
					
					<label for="address">Address</label>
					<textarea name="address" id="address" required></textarea>
					
					<br /> <br />
					<input type="submit" value="Submit Order" />
					<a href="<?php echo asset('/') ?>">Continue Shopping</a>
				</form>
			</div>
		</div>
		
		<div class="footer">
			&copy; <?php echo date("Y") ?>. All right reserved.
		</div>
	</body>
</html>