<! doctype html>

<html>
	<head><title>Book Detail</title>
	<link rel="stylesheet" href="<?php echo asset('packages/assets/css/Hstyle.css')?>" />
	</head>
	<body>
		<h1>Book Detail</h1>
	
		<div class="detail">
			<a href="<?php echo asset('/')?>" class="back">&laquo; Go Back</a>
			
			<?php if(!is_dir("packages/assets/img/covers/$book->cover") and file_exists("packages/assets/img/covers/$book->cover")): ?>
				<img src="<?php echo asset('packages/assets/img/covers/'.$book->cover) ?>" height="150"/>
			<?php else: ?>
				<img src="<?php echo asset('packages/assets/img/covers/no-cover.gif') ?>" alt="" height="150">
			<?php endif; ?>
			
			<h2><?php echo $book->title ?></h2>
			<i>by <?php echo $book->author ?></i>
			<b>$<?php echo $book->price ?></b>
			
			<p><?php echo $book->summary ?></p>
			
			<a href="<?php echo asset('bookList/cart/'.$book->id)?>" class="add-to-cart">
				Add to CArt
			</a>
		</div>
		
		<div class="footer">
			&copy; <?php echo date("Y") ?>. All right reserved.
		</div>
	</body>
</html>