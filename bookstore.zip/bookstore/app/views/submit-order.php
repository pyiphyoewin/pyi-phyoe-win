<!doctype html>
<html>
<head>
	<title>Order Submitted</title>
	<link rel="stylesheet" href="<?php echo asset('packages/assets/css/Hstyle.css')?>">
</head>
<body>
	<h1>Order Submitted</h1>
	
	<div class="msg">
		Your order has been submitted. We'll deliver the items soon.
		<a href="<?php echo asset('/') ?>" class="done">Book Store Home</a>
	</div>
	
	<div class="footer">
		&copy; <?php echo date("Y") ?>. All right reserved.
	</div>
</body>
</html>